import React, { Component } from "react";
import renderHTML from 'react-render-html';
import YouTube from 'react-youtube';
import ArticleCardPage from './ArticleCardPage';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  control: {
    padding: theme.spacing.unit * 2,
  },
});

class ArticleDetails extends Component {
  constructor(props) {
    super(props);

    this.state = {
      player1: undefined,
      player2: undefined
    };

    this._onReady1 = this._onReady1.bind(this);
    this._onReady2 = this._onReady2.bind(this);
    this._onPlayerStateChange1 = this._onPlayerStateChange1.bind(this);
    this._onPlayerStateChange2 = this._onPlayerStateChange2.bind(this);
  }

  _onReady1(event) {
    this.state.player1 = event.target;
  }

  _onReady2(event) {
    this.state.player2 = event.target;
  }

  _onPlayerStateChange1(event) {
    if (event.data === YouTube.PlayerState.PLAYING) {
      this.state.player2.pauseVideo();
    }
  }

  _onPlayerStateChange2(event) {
    if (event.data === YouTube.PlayerState.PLAYING) {
      this.state.player1.pauseVideo();
    }
  }

  render() {
    const opts = {
      height: '300',
      width: '450',
      playerVars: { // https://developers.google.com/youtube/player_parameters
        //autoplay: 1
      }
    };

    const { classes, article } = this.props;
    const spacing = '16';
  
      return (
        <div className={classes.root}>
          <h1/>
          <Grid container spacing={24}>
            <Grid item xs={12} sm={7}>
              <ArticleCardPage className={classes.paper} article = {article}/>
            </Grid>
            <Grid item xs={12} sm={5}>
              {article.videos[1] && (
                    <React.Fragment>
                      <YouTube
                        videoId={article.videos[0].video_id}
                        opts={opts}
                        onReady={this._onReady1}
                        onStateChange={this._onPlayerStateChange1}
                      />
                      <YouTube
                        videoId={article.videos[1].video_id}
                        opts={opts}
                        onReady={this._onReady2}
                        onStateChange={this._onPlayerStateChange2}
                      />
                    </React.Fragment>
                  )}
              </Grid>
          </Grid>
          <p>viewed:{article.view_count} times</p>
          <p>created at: {new Date (article.created_at).toLocaleString()}</p>
          <p>updated at: {new Date (article.updated_at).toLocaleString()}</p>
        </div>
        // <Grid container className={classes.root} spacing={16}>
        //   <Grid item xs={6}>
        //     <Grid container className={classes.demo} justify="center" spacing={Number(spacing)}>
        //         <Grid key={1} item>
        //           <Paper className={classes.paper} />
        //           <ArticleCardPage article = {article}/>
        //           <p>{article.view_count}</p>
        //           <p>{article.created_at.toLocaleString()}</p>
        //           <p>{article.updated_at.toLocaleString()}</p>
        //         </Grid>
        //         <Grid key={2} item>
        //           <Paper className={classes.paper} />
        //           {article.videos && (
        //             <React.Fragment>
        //               <YouTube
        //                 videoId={article.videos[0].video_id}
        //                 opts={opts}
        //                 onReady={this._onReady1}
        //                 onStateChange={this._onPlayerStateChange1}
        //               />
        //               <YouTube
        //                 videoId={article.videos[1].video_id}
        //                 opts={opts}
        //                 onReady={this._onReady2}
        //                 onStateChange={this._onPlayerStateChange2}
        //               />
        //             </React.Fragment>
        //           )}
        //         </Grid>
        //     </Grid>
        //   </Grid>
        // </Grid>

        // <div> 
        // {/* <h2>{article.title}</h2> */}
        // <ArticleCardPage article = {article}/>
        // {/* {this.props.images && (
        // <React.Fragment>
        // {this.props.images.map((image) => (
        //   <img key={image.url} src={image.url} alt="" height="200" width="200"/>
        // ))}
        // </React.Fragment>
        // )} */}
        // {article.videos && (
        // <React.Fragment>
        //   <YouTube
        //     videoId={article.videos[0].video_id}
        //     opts={opts}
        //     onReady={this._onReady1}
        //     onStateChange={this._onPlayerStateChange1}
        //   />
        //   <YouTube
        //     videoId={article.videos[1].video_id}
        //     opts={opts}
        //     onReady={this._onReady2}
        //     onStateChange={this._onPlayerStateChange2}
        //   />
        // </React.Fragment>
        // )}
        // {/* {renderHTML(this.props.body)} */}
        // {/* <p>{this.props.body}</p> */}
        // {/* <p>By {props.author.first_name}</p> */}

        // </div>
      )
  }
}

ArticleDetails.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(ArticleDetails);