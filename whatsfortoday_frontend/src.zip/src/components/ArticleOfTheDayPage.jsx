import React, { Component } from "react";
import Article from "../requests/article";
import User from "../requests/user";
import ArticleShowPage from "./ArticleShowPage";

class ArticleOfTheDayPage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      loading: true,
      article: undefined
    };
  }

  componentDidMount() {
    if(this.props.match && this.props.match.params.id){
        //const currentUser = this.props.currentUser;
        const userId = this.props.match.params.id;
        console.log("Fetching Article of the day for userId:"+userId);     
        User.articleOfTheDay(userId)
        .then(dayArticle => {
            if(dayArticle) {
              console.log("Article of the day returned from server is:"+dayArticle);
              this.setState({ loading: false, article: dayArticle });
            } else {
              this.setState({ loading: false });
            }
        })
        .catch(() => {
          this.setState({ loading: false });
        });
    } else {
        console.log("Fetching Article of the day for public!");     
        Article.articleOfTheDay()
        .then(dayArticle => {
            if(dayArticle) {
              console.log("Article of the day returned from server is:"+dayArticle.title);
              this.setState({ loading: false, article: dayArticle });
            } else {
              this.setState({ loading: false });
            }
        })
        .catch(() => {
          this.setState({ loading: false });
        });
    }
   
  }

  render() {
    
    const { loading, article } = this.state;

    if (loading) {
      return (
        <main>
          <h2>Loading...</h2>
        </main>
      );
    }

    if(!article) {
        return (
            <main>
              <h5>Sorry! System is having trouble getting the article of the day! Please try later. </h5>
            </main>
        );
    }

    return (
      <main>
        <h1>Here is your article of the day!</h1>
        <ArticleShowPage articleOfTheDay={article}/> 
      </main>
    );
  }
}

export default ArticleOfTheDayPage;