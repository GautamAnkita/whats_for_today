import React, { Component } from "react";
import ArticleDetails from "./ArticleDetails";
import CommentList from "./CommentList";
import Article from "../requests/article";
import User from "../requests/user";
import { isError } from "util";


class ArticleShowPage extends Component {
    constructor(props) {
      super(props);
  
      this.state = {
        loading: true,
        article: undefined,
        viewer: undefined
      };

      this.deleteComment = this.deleteComment.bind(this);
    //   this.newAnswer = this.newAnswer.bind(this);
    }
  
    componentDidMount() {
        if(this.props.match) {
            if(this.props.match.params.id){
                let viewer = "public";
                let user = null;
                if(this.props.currentUser) {
                  user = this.props.currentUser;
                }
                const articleId = this.props.match.params.id;
                Article.one(articleId)
                .then(article => {
                    if(!article) {
                        this.setState({ loading: false });
                    } else {
                        console.log(article);
                        if(user) {
                          if(user.is_admin) {
                            viewer = "admin";
                          } else if(user.id === article.author_id ) {
                            viewer = "author";
                          } else {
                            viewer = "user";
                          }
                        }
                        console.log("The article being shown is:"+article.title+" for the viewer:"+ viewer);
                        this.setState({ loading: false, article: article, viewer: viewer });
                    }
                })
                .catch(() => {
                this.setState({ loading: false });
                });
            } else {
                  const userId = this.props.match.params.userId;
                  const artId = this.props.match.params.artId;
                  const user = this.props.currentUser;
                  console.log("User Id:"+userId);
                  console.log("Art Id:"+artId);
                  //console.log("User name:"+user.first_name);
                  User.publishedArticle(userId, artId)
                  .then(article => {
                      if(!article) {
                          this.setState({ loading: false });
                      } else {
                          console.log(article);
                          let viewer = "user";
                          // if(user.is_admin) {
                          //   viewer = "admin";
                          // } else if(user.id === article.author_id ) {
                          //   viewer = "author";
                          // } else {
                          //   viewer = "user";
                          // } 
                          console.log("The article being shown is:"+article.title+" for the viewer:"+ viewer);
                          this.setState({ loading: false, article: article, viewMode: 'U_ART' });
                      }
                  })
                  .catch(() => {
                  this.setState({ loading: false });
                  });
            }
            
        }

        if(this.props.articleOfTheDay) {
            const article = this.props.articleOfTheDay;
            console.log("Got the article from props "+article);
            this.setState({ loading: false, article: article, viewMode: 'D_ART' });
        }
    }

    // newAnswer(body) {
    //   const { question } = this.state;
    //   const { answers = [] } = question;
    //   const questionId = question.id;
    //   Question.createAns(questionId, 
    //     {
    //       body: body
    //     }
    //   ).then(data => {
    //     const currTime = new Date().toLocaleString();
    //     const newAns = {
    //       id: data.id,
    //       body: body,
    //       author: question.author,
    //       created_at: currTime
    //     };
    //     answers.unshift(newAns);
    //     this.setState({question: question, answers: answers });
    //     // console.log("Successfully Created Answer!");
    //     // Question.one(questionId)
    //     // .then(question => {
    //     //   console.log(question);
    //     //   this.setState({question: question });
    //     // })
    //     // .catch(() => {
    //     //   this.setState({ loading: false });
    //     // });
    //   });
    // }
  
    deleteComment(id) {
      const { article } = this.state;
      const { comments = [] } = article;
      const articleId = article.id;
      Article.deleteComment(articleId, id)
      .then(data => {
        this.setState({
          article: {
            ...article,
            comments: comments.filter(comment => comment.id !== id)
          }
        });
      });
    }
  
    render() {
      const { loading, article } = this.state;
  
      if (loading) {
        return (
          <main>
            <h2>Loading...</h2>
          </main>
        );
      }
  
      if (!article) {
        return (
          <main>
            <h2>Article doesn't exist</h2>
          </main>
        );
      }
  
      return (
        <main>
          <ArticleDetails article={article} />
          {/* <button onClick={this.deleteQuestion}>Delete</button> */}
          {/* <AnswerNew OnNewAnswer={this.newAnswer}/>*/}
          <h2>Comments</h2>
          <CommentList
            onCommentDeleteClick={this.deleteComment}
            comments={article.comments}
          /> 
        </main>
      );
    }
}
  
export default ArticleShowPage;