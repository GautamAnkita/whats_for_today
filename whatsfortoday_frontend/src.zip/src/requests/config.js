export const HOST = "localhost:3000";
export const API_BASE = "/v1";
export const BASE_URL = `http://${HOST}${API_BASE}`;